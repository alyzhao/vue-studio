<template>
	<div class="el-wrap">
		<router-view />
	</div>
</template>
<style>
	.el-wrap {
		height: 100%;
	}
</style>