exports.prodUrl = {
	HOST: 'https://www.yunqi2050.com/',
	staticHost: './',
	imgHost: 'https://www.yunqi2050.com/2050website/img/'
}

/*测试环境*/
// exports.prodUrl = {
//     HOST: 'http://101.132.116.106:80',
//     staticHost: 'http://101.132.116.106:80/dist/',
//     imgHost: 'http://101.132.116.106:80/2050website/img/'
// }
